"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var tasks_service_1 = require("~/shared/tasks/tasks.service");
var forms_1 = require("@angular/forms");
var TaskFormComponent = /** @class */ (function () {
    function TaskFormComponent(tasksService, formBuilder) {
        this.tasksService = tasksService;
        this.formBuilder = formBuilder;
        this.taskFormGroup = this.formBuilder.group({
            description: ['', forms_1.Validators.required]
        });
    }
    TaskFormComponent.prototype.ngOnInit = function () { };
    TaskFormComponent.prototype.onSave = function () {
        this.tasksService.addTask(this.taskFormGroup.value.description);
        this.taskFormGroup.reset();
    };
    TaskFormComponent = __decorate([
        core_1.Component({
            selector: 'task-form',
            moduleId: module.id,
            templateUrl: './task-form.component.html',
            styleUrls: ['./task-form.component.css']
        }),
        __metadata("design:paramtypes", [tasks_service_1.TaskService, forms_1.FormBuilder])
    ], TaskFormComponent);
    return TaskFormComponent;
}());
exports.TaskFormComponent = TaskFormComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGFzay1mb3JtLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInRhc2stZm9ybS5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBa0Q7QUFDbEQsOERBQTJEO0FBRTNELHdDQUFvRTtBQU9wRTtJQU1FLDJCQUFZLFlBQXlCLEVBQUUsV0FBd0I7UUFDN0QsSUFBSSxDQUFDLFlBQVksR0FBRyxZQUFZLENBQUM7UUFDakMsSUFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7UUFDL0IsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQztZQUMxQyxXQUFXLEVBQUUsQ0FBQyxFQUFFLEVBQUUsa0JBQVUsQ0FBQyxRQUFRLENBQUM7U0FDdkMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELG9DQUFRLEdBQVIsY0FBa0IsQ0FBQztJQUVuQixrQ0FBTSxHQUFOO1FBQ0UsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDaEUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUM3QixDQUFDO0lBbkJVLGlCQUFpQjtRQU43QixnQkFBUyxDQUFDO1lBQ1QsUUFBUSxFQUFFLFdBQVc7WUFDckIsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ25CLFdBQVcsRUFBRSw0QkFBNEI7WUFDekMsU0FBUyxFQUFFLENBQUMsMkJBQTJCLENBQUM7U0FDekMsQ0FBQzt5Q0FPMEIsMkJBQVcsRUFBZSxtQkFBVztPQU5wRCxpQkFBaUIsQ0FvQjdCO0lBQUQsd0JBQUM7Q0FBQSxBQXBCRCxJQW9CQztBQXBCWSw4Q0FBaUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBUYXNrU2VydmljZSB9IGZyb20gJ34vc2hhcmVkL3Rhc2tzL3Rhc2tzLnNlcnZpY2UnO1xyXG5cclxuaW1wb3J0IHsgRm9ybUdyb3VwLCBGb3JtQnVpbGRlciwgVmFsaWRhdG9ycyB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICd0YXNrLWZvcm0nLFxyXG4gIG1vZHVsZUlkOiBtb2R1bGUuaWQsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL3Rhc2stZm9ybS5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmxzOiBbJy4vdGFzay1mb3JtLmNvbXBvbmVudC5jc3MnXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgVGFza0Zvcm1Db21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gIHByaXZhdGUgdGFza3NTZXJ2aWNlOiBUYXNrU2VydmljZTtcclxuICBwcml2YXRlIGZvcm1CdWlsZGVyOiBGb3JtQnVpbGRlcjtcclxuXHJcbiAgcHVibGljIHRhc2tGb3JtR3JvdXA6IEZvcm1Hcm91cDtcclxuXHJcbiAgY29uc3RydWN0b3IodGFza3NTZXJ2aWNlOiBUYXNrU2VydmljZSwgZm9ybUJ1aWxkZXI6IEZvcm1CdWlsZGVyKSB7XHJcbiAgICB0aGlzLnRhc2tzU2VydmljZSA9IHRhc2tzU2VydmljZTtcclxuICAgIHRoaXMuZm9ybUJ1aWxkZXIgPSBmb3JtQnVpbGRlcjtcclxuICAgIHRoaXMudGFza0Zvcm1Hcm91cCA9IHRoaXMuZm9ybUJ1aWxkZXIuZ3JvdXAoe1xyXG4gICAgICBkZXNjcmlwdGlvbjogWycnLCBWYWxpZGF0b3JzLnJlcXVpcmVkXVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpOiB2b2lkIHt9XHJcblxyXG4gIG9uU2F2ZSgpIHtcclxuICAgIHRoaXMudGFza3NTZXJ2aWNlLmFkZFRhc2sodGhpcy50YXNrRm9ybUdyb3VwLnZhbHVlLmRlc2NyaXB0aW9uKTtcclxuICAgIHRoaXMudGFza0Zvcm1Hcm91cC5yZXNldCgpO1xyXG4gIH1cclxufVxyXG4iXX0=