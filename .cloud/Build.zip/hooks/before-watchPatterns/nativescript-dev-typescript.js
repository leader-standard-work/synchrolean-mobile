module.exports = require("nativescript-dev-typescript/lib/before-watchPatterns.js");
