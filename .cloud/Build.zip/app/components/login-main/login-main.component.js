"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var LoginMainComponent = /** @class */ (function () {
    function LoginMainComponent() {
    }
    LoginMainComponent.prototype.ngOnInit = function () { };
    LoginMainComponent = __decorate([
        core_1.Component({
            selector: 'login-main',
            moduleId: module.id,
            templateUrl: './login-main.component.html',
            styleUrls: ['./login-main.component.css'],
        })
    ], LoginMainComponent);
    return LoginMainComponent;
}());
exports.LoginMainComponent = LoginMainComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9naW4tbWFpbi5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJsb2dpbi1tYWluLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUFrRDtBQVVoRDtJQUFBO0lBTUYsQ0FBQztJQURDLHFDQUFRLEdBQVIsY0FBaUIsQ0FBQztJQUxMLGtCQUFrQjtRQU5oQyxnQkFBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLFlBQVk7WUFDdEIsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ25CLFdBQVcsRUFBRSw2QkFBNkI7WUFDMUMsU0FBUyxFQUFFLENBQUMsNEJBQTRCLENBQUM7U0FDMUMsQ0FBQztPQUNXLGtCQUFrQixDQU1oQztJQUFELHlCQUFDO0NBQUEsQUFOQyxJQU1EO0FBTmMsZ0RBQWtCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbmltcG9ydCB7IEZvcm1Hcm91cCwgRm9ybUJ1aWxkZXIsIFZhbGlkYXRvcnMgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAnbG9naW4tbWFpbicsXHJcbiAgICBtb2R1bGVJZDogbW9kdWxlLmlkLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2xvZ2luLW1haW4uY29tcG9uZW50Lmh0bWwnLFxyXG4gICAgc3R5bGVVcmxzOiBbJy4vbG9naW4tbWFpbi5jb21wb25lbnQuY3NzJ10sXHJcbiAgfSlcclxuICBleHBvcnQgY2xhc3MgTG9naW5NYWluQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuXHJcblxyXG4gIFxyXG5cclxuICBuZ09uSW5pdCgpOiB2b2lke31cclxufVxyXG4iXX0=