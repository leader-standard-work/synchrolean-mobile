"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("nativescript-angular/router");
var operators_1 = require("rxjs/operators");
var tasks_service_1 = require("~/shared/tasks/tasks.service");
var TaskDetailComponent = /** @class */ (function () {
    function TaskDetailComponent(taskService, pageRoute) {
        var _this = this;
        this.tasksService = taskService;
        this.pageRoute.activatedRoute
            .pipe(operators_1.switchMap(function (activatedRoute) { return activatedRoute.params; }))
            .forEach(function (params) {
            _this.task = _this.tasksService.getTaskById(+params['id']);
        });
    }
    TaskDetailComponent.prototype.ngOnInit = function () { };
    TaskDetailComponent = __decorate([
        core_1.Component({
            selector: 'task-detail',
            moduleId: module.id,
            templateUrl: './task-detail.component.html',
            styleUrls: ['./task-detail.component.css']
        }),
        __metadata("design:paramtypes", [tasks_service_1.TaskService, router_1.PageRoute])
    ], TaskDetailComponent);
    return TaskDetailComponent;
}());
exports.TaskDetailComponent = TaskDetailComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGFzay1kZXRhaWwuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsidGFzay1kZXRhaWwuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQWtEO0FBQ2xELHNEQUF3RDtBQUN4RCw0Q0FBMkM7QUFDM0MsOERBQTJEO0FBUzNEO0lBTUUsNkJBQVksV0FBd0IsRUFBRSxTQUFvQjtRQUExRCxpQkFPQztRQU5DLElBQUksQ0FBQyxZQUFZLEdBQUcsV0FBVyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYzthQUMxQixJQUFJLENBQUMscUJBQVMsQ0FBQyxVQUFBLGNBQWMsSUFBSSxPQUFBLGNBQWMsQ0FBQyxNQUFNLEVBQXJCLENBQXFCLENBQUMsQ0FBQzthQUN4RCxPQUFPLENBQUMsVUFBQSxNQUFNO1lBQ2IsS0FBSSxDQUFDLElBQUksR0FBRyxLQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQzNELENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELHNDQUFRLEdBQVIsY0FBa0IsQ0FBQztJQWZSLG1CQUFtQjtRQU4vQixnQkFBUyxDQUFDO1lBQ1QsUUFBUSxFQUFFLGFBQWE7WUFDdkIsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ25CLFdBQVcsRUFBRSw4QkFBOEI7WUFDM0MsU0FBUyxFQUFFLENBQUMsNkJBQTZCLENBQUM7U0FDM0MsQ0FBQzt5Q0FPeUIsMkJBQVcsRUFBYSxrQkFBUztPQU4vQyxtQkFBbUIsQ0FnQi9CO0lBQUQsMEJBQUM7Q0FBQSxBQWhCRCxJQWdCQztBQWhCWSxrREFBbUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBQYWdlUm91dGUgfSBmcm9tICduYXRpdmVzY3JpcHQtYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyBzd2l0Y2hNYXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XHJcbmltcG9ydCB7IFRhc2tTZXJ2aWNlIH0gZnJvbSAnfi9zaGFyZWQvdGFza3MvdGFza3Muc2VydmljZSc7XHJcbmltcG9ydCB7IFRhc2sgfSBmcm9tICd+L3NoYXJlZC90YXNrcy90YXNrJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAndGFzay1kZXRhaWwnLFxyXG4gIG1vZHVsZUlkOiBtb2R1bGUuaWQsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL3Rhc2stZGV0YWlsLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybHM6IFsnLi90YXNrLWRldGFpbC5jb21wb25lbnQuY3NzJ11cclxufSlcclxuZXhwb3J0IGNsYXNzIFRhc2tEZXRhaWxDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gIHByaXZhdGUgdGFza3NTZXJ2aWNlOiBUYXNrU2VydmljZTtcclxuICBwcml2YXRlIHBhZ2VSb3V0ZTogUGFnZVJvdXRlO1xyXG5cclxuICBwdWJsaWMgdGFzazogVGFzaztcclxuXHJcbiAgY29uc3RydWN0b3IodGFza1NlcnZpY2U6IFRhc2tTZXJ2aWNlLCBwYWdlUm91dGU6IFBhZ2VSb3V0ZSkge1xyXG4gICAgdGhpcy50YXNrc1NlcnZpY2UgPSB0YXNrU2VydmljZTtcclxuICAgIHRoaXMucGFnZVJvdXRlLmFjdGl2YXRlZFJvdXRlXHJcbiAgICAgIC5waXBlKHN3aXRjaE1hcChhY3RpdmF0ZWRSb3V0ZSA9PiBhY3RpdmF0ZWRSb3V0ZS5wYXJhbXMpKVxyXG4gICAgICAuZm9yRWFjaChwYXJhbXMgPT4ge1xyXG4gICAgICAgIHRoaXMudGFzayA9IHRoaXMudGFza3NTZXJ2aWNlLmdldFRhc2tCeUlkKCtwYXJhbXNbJ2lkJ10pO1xyXG4gICAgICB9KTtcclxuICB9XHJcblxyXG4gIG5nT25Jbml0KCk6IHZvaWQge31cclxufVxyXG4iXX0=