import { Component, OnInit } from '@angular/core';

import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
    selector: 'login-main',
    moduleId: module.id,
    templateUrl: './login-main.component.html',
    styleUrls: ['./login-main.component.css'],
  })
  export class LoginMainComponent implements OnInit {


  

  ngOnInit(): void{}
}
