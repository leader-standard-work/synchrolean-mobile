"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("nativescript-angular/router");
var task_list_component_1 = require("./components/task-list/task-list.component");
var task_form_component_1 = require("./components/task-form/task-form.component");
var task_detail_component_1 = require("~/components/task-detail/task-detail.component");
//Demming -- Import for routing to login-main page 
var login_main_component_1 = require("~/components/login-main/login-main.component");
var routes = [
    { path: '', redirectTo: '/task-list', pathMatch: 'full' },
    { path: 'task-list', component: task_list_component_1.TaskListComponent },
    { path: 'task-form', component: task_form_component_1.TaskFormComponent },
    { path: 'task-detail/:id', component: task_detail_component_1.TaskDetailComponent },
    { path: 'login-main', component: login_main_component_1.LoginMainComponent } //Demming -- Route to login main page
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        core_1.NgModule({
            imports: [router_1.NativeScriptRouterModule.forRoot(routes)],
            exports: [router_1.NativeScriptRouterModule]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());
exports.AppRoutingModule = AppRoutingModule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwLnJvdXRpbmcuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJhcHAucm91dGluZy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUF5QztBQUN6QyxzREFBdUU7QUFHdkUsa0ZBQStFO0FBQy9FLGtGQUErRTtBQUMvRSx3RkFBcUY7QUFDckYsbURBQW1EO0FBQ25ELHFGQUFrRjtBQUVsRixJQUFNLE1BQU0sR0FBVztJQUNyQixFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsVUFBVSxFQUFFLFlBQVksRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFO0lBQ3pELEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsdUNBQWlCLEVBQUU7SUFDbkQsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSx1Q0FBaUIsRUFBRTtJQUNuRCxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRSxTQUFTLEVBQUUsMkNBQW1CLEVBQUU7SUFDM0QsRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFLFNBQVMsRUFBRSx5Q0FBa0IsRUFBRSxDQUFBLHFDQUFxQztDQUMzRixDQUFDO0FBTUY7SUFBQTtJQUErQixDQUFDO0lBQW5CLGdCQUFnQjtRQUo1QixlQUFRLENBQUM7WUFDUixPQUFPLEVBQUUsQ0FBQyxpQ0FBd0IsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDbkQsT0FBTyxFQUFFLENBQUMsaUNBQXdCLENBQUM7U0FDcEMsQ0FBQztPQUNXLGdCQUFnQixDQUFHO0lBQUQsdUJBQUM7Q0FBQSxBQUFoQyxJQUFnQztBQUFuQiw0Q0FBZ0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBOYXRpdmVTY3JpcHRSb3V0ZXJNb2R1bGUgfSBmcm9tICduYXRpdmVzY3JpcHQtYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyBSb3V0ZXMgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5cclxuaW1wb3J0IHsgVGFza0xpc3RDb21wb25lbnQgfSBmcm9tICcuL2NvbXBvbmVudHMvdGFzay1saXN0L3Rhc2stbGlzdC5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBUYXNrRm9ybUNvbXBvbmVudCB9IGZyb20gJy4vY29tcG9uZW50cy90YXNrLWZvcm0vdGFzay1mb3JtLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IFRhc2tEZXRhaWxDb21wb25lbnQgfSBmcm9tICd+L2NvbXBvbmVudHMvdGFzay1kZXRhaWwvdGFzay1kZXRhaWwuY29tcG9uZW50JztcclxuLy9EZW1taW5nIC0tIEltcG9ydCBmb3Igcm91dGluZyB0byBsb2dpbi1tYWluIHBhZ2UgXHJcbmltcG9ydCB7IExvZ2luTWFpbkNvbXBvbmVudCB9IGZyb20gJ34vY29tcG9uZW50cy9sb2dpbi1tYWluL2xvZ2luLW1haW4uY29tcG9uZW50JztcclxuXHJcbmNvbnN0IHJvdXRlczogUm91dGVzID0gW1xyXG4gIHsgcGF0aDogJycsIHJlZGlyZWN0VG86ICcvdGFzay1saXN0JywgcGF0aE1hdGNoOiAnZnVsbCcgfSxcclxuICB7IHBhdGg6ICd0YXNrLWxpc3QnLCBjb21wb25lbnQ6IFRhc2tMaXN0Q29tcG9uZW50IH0sXHJcbiAgeyBwYXRoOiAndGFzay1mb3JtJywgY29tcG9uZW50OiBUYXNrRm9ybUNvbXBvbmVudCB9LFxyXG4gIHsgcGF0aDogJ3Rhc2stZGV0YWlsLzppZCcsIGNvbXBvbmVudDogVGFza0RldGFpbENvbXBvbmVudCB9LFxyXG4gIHsgcGF0aDogJ2xvZ2luLW1haW4nLCBjb21wb25lbnQ6IExvZ2luTWFpbkNvbXBvbmVudCB9Ly9EZW1taW5nIC0tIFJvdXRlIHRvIGxvZ2luIG1haW4gcGFnZVxyXG5dO1xyXG5cclxuQE5nTW9kdWxlKHtcclxuICBpbXBvcnRzOiBbTmF0aXZlU2NyaXB0Um91dGVyTW9kdWxlLmZvclJvb3Qocm91dGVzKV0sXHJcbiAgZXhwb3J0czogW05hdGl2ZVNjcmlwdFJvdXRlck1vZHVsZV1cclxufSlcclxuZXhwb3J0IGNsYXNzIEFwcFJvdXRpbmdNb2R1bGUge31cclxuIl19