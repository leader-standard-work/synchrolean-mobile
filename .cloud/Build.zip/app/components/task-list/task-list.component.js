"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var tasks_service_1 = require("../../shared/tasks/tasks.service");
var TaskListComponent = /** @class */ (function () {
    function TaskListComponent(tasksService) {
        this.tasksService = tasksService;
    }
    TaskListComponent.prototype.ngOnInit = function () {
        this.tasks$ = this.tasksService.getTasks();
    };
    TaskListComponent.prototype.toTaskDetail = function (item) {
    };
    TaskListComponent = __decorate([
        core_1.Component({
            selector: 'tasks-list',
            moduleId: module.id,
            templateUrl: './task-list.component.html',
            styleUrls: ['./task-list.component.css'],
        }),
        __metadata("design:paramtypes", [tasks_service_1.TaskService])
    ], TaskListComponent);
    return TaskListComponent;
}());
exports.TaskListComponent = TaskListComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGFzay1saXN0LmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInRhc2stbGlzdC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBa0Q7QUFHbEQsa0VBQStEO0FBUy9EO0lBRUUsMkJBQW9CLFlBQXlCO1FBQXpCLGlCQUFZLEdBQVosWUFBWSxDQUFhO0lBQUcsQ0FBQztJQUVqRCxvQ0FBUSxHQUFSO1FBQ0UsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQzdDLENBQUM7SUFFTSx3Q0FBWSxHQUFuQixVQUFvQixJQUFVO0lBRTlCLENBQUM7SUFWVSxpQkFBaUI7UUFON0IsZ0JBQVMsQ0FBQztZQUNULFFBQVEsRUFBRSxZQUFZO1lBQ3RCLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNuQixXQUFXLEVBQUUsNEJBQTRCO1lBQ3pDLFNBQVMsRUFBRSxDQUFDLDJCQUEyQixDQUFDO1NBQ3pDLENBQUM7eUNBR2tDLDJCQUFXO09BRmxDLGlCQUFpQixDQVc3QjtJQUFELHdCQUFDO0NBQUEsQUFYRCxJQVdDO0FBWFksOENBQWlCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbmltcG9ydCB7IFRhc2sgfSBmcm9tICcuLi8uLi9zaGFyZWQvdGFza3MvdGFzayc7XHJcbmltcG9ydCB7IFRhc2tTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vc2hhcmVkL3Rhc2tzL3Rhc2tzLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ3Rhc2tzLWxpc3QnLFxyXG4gIG1vZHVsZUlkOiBtb2R1bGUuaWQsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL3Rhc2stbGlzdC5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmxzOiBbJy4vdGFzay1saXN0LmNvbXBvbmVudC5jc3MnXSxcclxufSlcclxuZXhwb3J0IGNsYXNzIFRhc2tMaXN0Q29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuICBwdWJsaWMgdGFza3MkOiBPYnNlcnZhYmxlPEFycmF5PFRhc2s+PjtcclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHRhc2tzU2VydmljZTogVGFza1NlcnZpY2UpIHt9XHJcblxyXG4gIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgdGhpcy50YXNrcyQgPSB0aGlzLnRhc2tzU2VydmljZS5nZXRUYXNrcygpO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIHRvVGFza0RldGFpbChpdGVtOiBUYXNrKSB7XHJcbiAgICBcclxuICB9XHJcbn1cclxuIl19