"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var task_1 = require("./task");
var rxjs_1 = require("rxjs");
var TaskService = /** @class */ (function () {
    function TaskService() {
        this.tasks = new Array();
    }
    TaskService.prototype.getTasks = function () {
        return rxjs_1.of(this.tasks);
    };
    TaskService.prototype.addTask = function (description) {
        this.tasks.push(new task_1.Task(description));
        console.log(this.tasks);
    };
    TaskService.prototype.getTaskById = function (id) {
        for (var _i = 0, _a = this.tasks; _i < _a.length; _i++) {
            var task = _a[_i];
            if (task.getId() === id) {
                return task;
            }
        }
        return null;
    };
    TaskService = __decorate([
        core_1.Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [])
    ], TaskService);
    return TaskService;
}());
exports.TaskService = TaskService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGFza3Muc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInRhc2tzLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBMkM7QUFFM0MsK0JBQThCO0FBQzlCLDZCQUFzQztBQUt0QztJQUdFO1FBQ0UsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLEtBQUssRUFBUSxDQUFDO0lBQ2pDLENBQUM7SUFFTSw4QkFBUSxHQUFmO1FBQ0UsTUFBTSxDQUFDLFNBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDeEIsQ0FBQztJQUVNLDZCQUFPLEdBQWQsVUFBZSxXQUFtQjtRQUNoQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLFdBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzFCLENBQUM7SUFFTSxpQ0FBVyxHQUFsQixVQUFtQixFQUFVO1FBQzNCLEdBQUcsQ0FBQyxDQUFjLFVBQVUsRUFBVixLQUFBLElBQUksQ0FBQyxLQUFLLEVBQVYsY0FBVSxFQUFWLElBQVU7WUFBdEIsSUFBSSxJQUFJLFNBQUE7WUFDWixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDeEIsTUFBTSxDQUFDLElBQUksQ0FBQztZQUNkLENBQUM7U0FDRjtRQUNELE1BQU0sQ0FBQyxJQUFJLENBQUM7SUFDZCxDQUFDO0lBdkJVLFdBQVc7UUFIdkIsaUJBQVUsQ0FBQztZQUNWLFVBQVUsRUFBRSxNQUFNO1NBQ25CLENBQUM7O09BQ1csV0FBVyxDQXdCdkI7SUFBRCxrQkFBQztDQUFBLEFBeEJELElBd0JDO0FBeEJZLGtDQUFXIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuaW1wb3J0IHsgVGFzayB9IGZyb20gJy4vdGFzayc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUsIG9mIH0gZnJvbSAncnhqcyc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBUYXNrU2VydmljZSB7XHJcbiAgcHJpdmF0ZSB0YXNrczogQXJyYXk8VGFzaz47XHJcblxyXG4gIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgdGhpcy50YXNrcyA9IG5ldyBBcnJheTxUYXNrPigpO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIGdldFRhc2tzKCk6IE9ic2VydmFibGU8VGFza1tdPiB7XHJcbiAgICByZXR1cm4gb2YodGhpcy50YXNrcyk7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgYWRkVGFzayhkZXNjcmlwdGlvbjogc3RyaW5nKTogdm9pZCB7XHJcbiAgICB0aGlzLnRhc2tzLnB1c2gobmV3IFRhc2soZGVzY3JpcHRpb24pKTtcclxuICAgIGNvbnNvbGUubG9nKHRoaXMudGFza3MpO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIGdldFRhc2tCeUlkKGlkOiBudW1iZXIpIDogVGFzayB7XHJcbiAgICBmb3IgKCBsZXQgdGFzayBvZiB0aGlzLnRhc2tzKSB7XHJcbiAgICAgIGlmICh0YXNrLmdldElkKCkgPT09IGlkKSB7XHJcbiAgICAgICAgcmV0dXJuIHRhc2s7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxufVxyXG4iXX0=